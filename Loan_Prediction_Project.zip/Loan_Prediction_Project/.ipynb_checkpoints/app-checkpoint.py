import streamlit as st
import pandas as pd
import joblib

# Load trained model
model = joblib.load("model/loan_nb_model.pkl")

st.title("🏦 Loan Approval & Eligibility Prediction")

# User Input Form
Gender = st.selectbox("Gender", ["Male", "Female"])
Married = st.selectbox("Married", ["Yes", "No"])
Education = st.selectbox("Education", ["Graduate", "Not Graduate"])
Self_Employed = st.selectbox("Self Employed", ["Yes", "No"])
ApplicantIncome = st.number_input("Applicant Income", min_value=0)
CoapplicantIncome = st.number_input("Coapplicant Income", min_value=0)
LoanAmount = st.number_input("Loan Amount (in thousands)", min_value=0)
Loan_Amount_Term = st.selectbox("Loan Term", [360, 180, 120, 84])
Credit_History = st.selectbox("Credit History", [1.0, 0.0])
Property_Area = st.selectbox("Property Area", ["Urban", "Semiurban", "Rural"])

# Convert input to DataFrame
input_df = pd.DataFrame({
    'Gender': [1 if Gender == "Male" else 0],
    'Married': [1 if Married == "Yes" else 0],
    'Education': [0 if Education == "Graduate" else 1],
    'Self_Employed': [1 if Self_Employed == "Yes" else 0],
    'ApplicantIncome': [ApplicantIncome],
    'CoapplicantIncome': [CoapplicantIncome],
    'LoanAmount': [LoanAmount],
    'Loan_Amount_Term': [Loan_Amount_Term],
    'Credit_History': [Credit_History],
    'Property_Area': [2 if Property_Area == "Urban" else 1 if Property_Area == "Semiurban" else 0]
})

if st.button("Predict"):
    # Add missing 'Dependents' column with default value '0'
    input_df['Dependents'] = '0'  # or use 0 if model was trained on numeric

    # List of features in the same order as during model training
    expected_columns = ['Gender', 'Married', 'Dependents', 'Education', 'Self_Employed',
                        'ApplicantIncome', 'CoapplicantIncome', 'LoanAmount',
                        'Loan_Amount_Term', 'Credit_History', 'Property_Area']

    # Reorder columns to match training order
    input_df = input_df[expected_columns]

    # Predict
    prediction = model.predict(input_df)[0]
    result = "✅ Approved" if prediction == 1 else "❌ Not Approved"
    st.success(f"Prediction Result: {result}")
